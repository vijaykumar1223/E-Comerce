import React from 'react';
import Second from './Second';
import {BrowserRouter , Routes , Route} from 'react-router-dom'
import Third from './Third';
import Firstp from './Firstp';
import Add from './Add';
import Crt from './Crt';
import BuyNow from './BuyNow';
import Paynow from './Paynow';


function App() {
  return (
   <>
  <BrowserRouter>
    <Routes>
      <Route path='/' element={<Third/>}></Route>
      <Route path='/Second' element={<Second/>}> </Route>
      <Route path='/Third' element={<Third/>}></Route>
       <Route path='/Add' element={<Add/>}> </Route>
       <Route path='/cart' element={<Crt/>}> </Route>
       <Route path='/second' element={<Second/>}> </Route>
       <Route path='/BuyNow' element={<BuyNow/>}></Route>
       <Route path='/second' element={<Second/>}></Route>
       <Route path='/Paynow' element={<Paynow/>}></Route>
    </Routes>
   </BrowserRouter>
    </>
  );
}

export default App



//////////////////Memo///////////

// import React from 'react'
// import Home from './Memo/Home'

// const App = () => {
//   return (
//     <div>
//       <Home/>
     
//     </div>
//   )
// }

// export default App




// sachine copy//////////////

// import React, { useState } from 'react'
// import { BrowserRouter, Route, Routes } from 'react-router-dom'
// import Navbar from './component/Navbar'
// import Login from './component/Login'
// import User from './component/User'
// import Cart from './component/Cart'
// import Payment from './component/payment/Payment'
// import Api from './component/Api'
// import Footer from './component/footer/Footer'

// function  App() {
//   return (
//     <div>
//       <BrowserRouter>
//       {/* <Navbar/> */}
//       <Routes> 
//         {/* <Route path='/' element={<Login />}> </Route> */}
//         <Route path='/home' element={<User/>}> </Route>
//         <Route path='/cart' element={<Cart/>}> </Route>
//         {/* <Route path='/payment' element={<Payment/>}> </Route> */}
//       </Routes>
//       </BrowserRouter>
//       {/* <Api/> */}
//     </div>
//   )
// }

// export default App

