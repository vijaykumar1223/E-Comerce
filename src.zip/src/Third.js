import React, { useState } from 'react'
import './third.css'
import imgg from './images/ueer.png'
import { Link, useNavigate } from 'react-router-dom'

function Third() {
  const navigate = useNavigate()
  const [data, setDta] = useState()
  const [val, setVal] = useState()
  const[error,setError]=useState('')
  const [err,setArr]=useState('')


  const submit = () => {
    const pass = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/
    if (!data) {
      setError('password is required')
    } else if (!pass.test(data)) {
      setError('paasword is not valid')
    }else if(data){
      alert ('Password is Done')
    }
 if(!val){
    setArr('name is require ')
 }

  }
  


  return (
    <div>

      <><center>
        <div className='form'>
          <img id='img-2' src={imgg} />
          <span className='sn'>User Id</span><br></br>
          <input type={'text'} placeholder='User Name' onChange={(e)=>setVal(e.target.value)} /><br></br>
          <p>{err}</p>
          <span className='sn'>Password</span><br></br>
          <input type={'password'} placeholder='Password' onChange={(e) => setDta(e.target.value)} />
          <p style={{color:"orange"}}>

          {error}
          </p>
          {/* <p style={{color:'red'}}>password is requred</p> */}
          <br></br>
        
          <button onClick={()=>navigate('/Second')} className='btn-smit'>Submit</button>
          
          {/* <Link to={'Firstp'}>submit</Link> */}

        </div></center>
      </>
    </div>
  )
}

export default Third