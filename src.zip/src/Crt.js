import React, { useState } from 'react'
import './crt.css'
import { Link, Navigate, useNavigate } from 'react-router-dom'

function Crt(props) {
    const navigate=useNavigate()
    const [val, setVal] = useState(1)

    const reactdata = () => {
        const reactData = localStorage.getItem('cart')
        if (reactData) {
            return JSON.parse(reactData)
        }
        else {
            return []
        }
    }
    const [cart, setCart] = useState(reactdata())



    return (
        <div className='body' >
        <div className='nav'>
        <h1 id='pay'>Payment</h1>
        <Link to={'/second'} >
            <h3 id='home'>Home</h3>
        </Link>
        </div>
            {

                cart.map((v, i) => {
                    return <div className='main' key={i}>
                        <img id='im' style={{ height: '300px',width:'300px', margin: '20px' }} src={v.Image}></img>
                        <div className='tags'>
                            <h3>Value:{v.product}</h3>
                            <h2>Price:{v.Price}</h2>
                            <p style={{color:'black'}}>Detail:-It is the nice product use the helful <br/> good Quantity and best product </p>


                            <span><button className='btn-1' onClick={(e) => setVal(val + 1)}>Quantity</button>
                                <h3>:{val}</h3></span>
                        <div className='btn-2'>
                            <button id='bt-2' onClick={()=>navigate('/BuyNow')} >BUY NOW</button>
                        </div>
                        </div>
                    </div>
                })
            }
        </div>
    )
}

export default Crt