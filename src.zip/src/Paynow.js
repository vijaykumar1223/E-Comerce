import React from 'react'
import './Buynow.css'
import { Link } from 'react-router-dom'

function Paynow() {
  return (
    <div className='suc'>
     <center> <div
      id='p' >Succesful Pay <br></br>
      <Link  to={'/second'}>Home</Link>
      </div></center>

     <div >
<h2></h2>
{/* <button>PAY</button> */}
     </div>
    </div>
  )
}

export default Paynow