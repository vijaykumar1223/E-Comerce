// import React, { useState } from 'react'
// import { useNavigate } from 'react-router-dom'
// import './cart.css'

// function Cart(props) {

//     const navigate = useNavigate()
    
//  const reactData = ()=>{
//     const cartData = localStorage.getItem('cart')
//     if(cartData){
//         return JSON.parse(cartData)
//     }
//     else{
//         return []
//     }
//  }
//     const [data, setData] = useState(0)

//     const[cart,setCart]=useState(reactData())

//     // console.log(cart.length)

//     function remo(index){
//        const data =  cart.filter((v)=>{
//             return v.id!==index
           
//         })
//         setCart(data)
//     }
//     return (
//         <>

//         <div className='container'>

//             <div className='row a' >
//                 <div className='col-lg-6'>

//                 <div className='flipcart'>
//                              <h3>FlipCart</h3>
//                              <h4>Grocery</h4>
//                          </div>

//                         <div className='address'>
//                             <h4>From Saved Addresses</h4>
//                             <button className='entry'>Entry Delivery PinCode</button>
//                         </div>

                        
//                         {/* <div className='container'> */}
//                           {/* <div className=' row product'> */}
//                             {

//                                 cart.map((value,index)=>{
//                                     return <div key={index} className=' row product'>
//                                         <div className=' col-lg-4 '><img src={value.avatar} id="val-ava"></img> </div>
//                                         <div className=' col-lg-4 val-name'>{value.name} <br/> <br/>
//                                         {value.description} <br/> <br/>
//                                         Rs.{value.price} <br/> <br/>
//                                          <button onClick={() => setData(data + 1)}>Quantity</button>
//                                          <span className='quanty'>: {data}</span><br/>
//                                         <button className='remove' onClick={()=>remo(value.id)}>Remove</button>
//                                         <button className='order' onClick={()=>navigate('/payment')}>Place Order</button>
//                                         </div>
//                                     </div>
//                                 })
//                             }
//                             {/* </div> */}
//                         {/* </div> */}

//                 </div>
//             </div>
//         </div>
        
//             <div className='container'>

//                 <div className='row a'>
//                     <div className='col-lg-6'>

//                         <div className='flipcart'>
//                             <h3>FlipCart</h3>
//                             <h4>Grocery</h4>

//                         </div>

//                         <div className='address'>
//                             <h4>From Saved Addresses</h4>
//                             <button className='entry'>Entry Delivery PinCode</button>
//                         </div>

//                         <div className='container'>

//                             <div className=' row product'>
//                                 <div className='col-lg-4'>

//                                     <img src='https://m.media-amazon.com/images/I/71fVoqRC0wL._SL1500_.jpghttps://m.media-amazon.com/images/I/71fVoqRC0wL._SL1500_.jpg'></img>
//                                 </div>

//                                 <div className='col-lg-4'>
//                                     <h2>iphone12</h2> <br />
//                                     <h3>Rs.50,000</h3><endl /><br />
//                                     <h4>Save for latter</h4><endl /> <br />
//                                     <h5>Remove</h5> <br />

//                                     <button onClick={() => setData(data + 1)}>Quantity</button><span className='quanty'>: {data}</span>
//                                     <button className='order'>Place Order</button>

//                                 </div>
//                             </div>
//                         </div>

//                     </div>

//                     <div className='col-lg-6'>
//                         <div className='row'>
//                             <div className='col-lg-4'>
//                                 <div className='price'>

//                                     <h2>Price Detail</h2>
//                                     <div className='item'>
//                                         <h4>Price(1 Item)</h4>
//                                         <h3>Rs.50,000</h3>
//                                     </div>

//                                     <div className='item1'>
//                                         <h4>Delivery Charge</h4>
//                                         <h3>Free</h3>
//                                     </div>
//                                     <div className='item2'>
//                                         <h4>Total  Price</h4>
//                                         <h3> Rs.50,000</h3>
//                                     </div>
//                                 </div>


//                             </div>

//                         </div>

//                     </div>
//                 </div>
//             </div>

//         </>
//     )
// }
// export default Cart





import React from 'react'


export const Cart = () => {
  return (
    <div>Cart</div>
  )
}
