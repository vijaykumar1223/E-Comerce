function User() {
    const [data, setData] = useState([])
    const [add, setAdd] = useState([])
    // console.log(add)
    const url = 'https://641beaeb1f5d999a446cb19d.mockapi.io/sachin'


    function Fetch() {
        axios.get(url)
            .then((res) => {
                setData(res.data)
            })
    }
    useEffect(() => {
        Fetch()
    }, [])

    useEffect(() => {
        const data = JSON.stringify(add)
        localStorage.setItem('cart', data)
    }, [add])

    return (
        <div className='main'>
            {

                data.map((value, index) => {
                    return <div className='main-body2'>
                        <img className='sa' src={value.avatar}></img> <br /> <br />
                        <h4> Name :{value.name}</h4> <br />
                        <h4>Description :{value.description}</h4><br />
                        <h4>Price :{value.price}</h4><br />
                        <button className='add'
                            onClick={() => setAdd([...add, value])}
                        > Add to Cart</button>
                        <button className='buy'>Buy to Cart</button>

                    </div>

                })
            }
            
        </div>
    )
}
export default User