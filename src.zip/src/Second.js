import React from 'react'
import './second.css'
import {  Link, useNavigate } from 'react-router-dom'
import Firstp from './Firstp'
function Second() {
  const navigate = useNavigate()
  return (
    <div>
        <>
       <div className='navbar-2'>
         <h2>Ecart  Shopping</h2>
        <input id='inc' type='text' placeholder='Search' />
       </div>
       <div className='container-fluid nav'>
       <Link id='lk'  to={'/Third'}>Login Form</Link>

       <Firstp />
       </div>

        </>
    </div>
  )
}

export default Second