import React, { useEffect, useState } from 'react'
import axios from 'axios'
import './firstp.css'
import Second from './Second'
import { Link, Navigate, useNavigate } from 'react-router-dom'
import Add from './Add'

function Firstp() {
    const navigate=useNavigate() 
    const [data, setData] = useState([])
    const [val,setVal]=useState({Image:'',Price:'',product:""})
    const [add , setAdd] = useState([])

    

    useEffect(()=>{
        const data = JSON.stringify(add)
        localStorage.setItem('cart',data)
    },[add])


    const url = 'https://641beaeb1f5d999a446cb19d.mockapi.io/sachin'
    const fetch = () => {
        axios.get(url)
            .then((res) => {
                setData(res.data)
            
            })
    }
    useEffect(()=>{
        fetch()
    },[])

    const Deleted=(indx)=>{
        axios.delete(`https://641beaeb1f5d999a446cb19d.mockapi.io/sachin/${indx}`).then(()=>{
            fetch()
        })
       
    }

    const handlechange =(e,type)=>{
        if(type=='a'){
            setVal({...val , Image:e.target.value})
        } else if(type=='b'){
            setVal({...val , Price:e.target.value})  
        } else if(type=='c'){
            setVal({...val , product:e.target.value})
        }

    }
    const handlesubit=(()=>{
        axios.post('https://641beaeb1f5d999a446cb19d.mockapi.io/sachin',val).then(()=>{

            fetch()
        })

    })
    return (
        
        <div className='bdy' >
        <div className='contact'>
         <h3 onClick={()=>navigate('')}>Home  Contact  About  +1188003344  </h3>
         
         </div>
        
         <Link style={{marginLeft:'1000px', color:'yellow' ,fontWeight:'bold'}} to={'/cart'}>
            <button id='ct-btn'>Cart 
            
            </button>
         </Link>
         <div id='two'>
         <center>
        <span id='sp' > Url Image :</span>
        <input type="text" value={val.Image} placeholder='Url ...' onChange={(e)=>handlechange(e,'a')}></input><br></br>
        <span id='sp'>Price :  </span>
        <input value={val.Price} placeholder='Price ' onChange={(e)=>handlechange(e,'b')}></input>
        <span id='sp'>Name  : </span>
        <input value={val.product} placeholder='Product' onChange={(e)=>handlechange(e,'c')}></input><br></br>
        <button id='btn1' onClick={handlesubit}>Add item </button></center></div>
           
           <div className='contain-main'>
            {
                data.map((val, ind) => {
                    return <center> <div id='main' key={ind}>
                    <img className='im' src={val.Image} />
                        <h3 id='tag-h'>Name:{val.product}</h3>
                        <h3 id='tag-hh'>Price:{val.Price} </h3>

                        {/* <button id='btn3' onClick={()=>navigate('/Add')}>Add Card </button> */}
                        <button id='btn3' onClick={()=>setAdd([...add , val])}>Add to Cart </button>
                        <button id='btn2' onClick={()=>Deleted(val.id)} >Delete</button>
                        
                    </div></center>
                })

            }</div>
        </div>
    )
}

export default Firstp