import React from 'react'

function Add() {
  return (
    <div>Add</div>
  )
}

export default Add