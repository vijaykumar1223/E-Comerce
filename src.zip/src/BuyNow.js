import React,{useEffect, useState} from 'react'
import { Link, Navigate, useNavigate } from 'react-router-dom'
import './Buynow.css'

function BuyNow() {

    const reactdata = () => {
        const reactData = localStorage.getItem('cart')
        if (reactData) {
            return JSON.parse(reactData)
        }
        else {
            return []
        }
    }

    const [cart, setCart] = useState(reactdata())
    const [price,setPrice]=useState()

   const totalPrice = cart.reduce((a,b)=>{
        return a + parseInt(b.Price)
   },0)

    useEffect(()=>{

    //     const Number =parseInt(totalPrice)
    setPrice(totalPrice)
    // console.log(totalPrice)
    },[])
    const Navigate = useNavigate()
    return (
        <div className='buynow'>
            <div className='nvr'>
                <Link id='link' to={'/second'}> Home</Link>
                <center><h2 id='tag-h1' >Detailes</h2> </center>
            </div>

            <div className='detail-form'>
                <h4>Full Name </h4>
                <input type='text' placeholder='Enter Name '></input><br />
                <h4>Address </h4>
                <input type='text' placeholder='Enter Name '></input><br />
                <h4>Contact Number </h4>
                <input type='number' placeholder='Enter Contact '></input><br />
                <h4>Email </h4>
                <input type='email' placeholder='Enter Email '></input><br />
                <h4>Pin</h4>
                <input type='number' placeholder='Enter Pin '></input><br />
                <h4> Details</h4>
                <input id='i-detal' type='' placeholder='Enter Details '></input><br />
            </div>

            <table>
                <thead>
                    <tr>
                        <td>Name</td>
                        <td>Value</td>
                        <td>Price</td>
                    </tr>
                </thead>
                <tbody>
                  {
                    cart&&cart.map((a)=>(
                        <>
                        <tr>
                        <td>{a.product}</td>
                        <td>{a.Detaile}</td>
                        <td>{a.Price}</td>
                        
                    </tr>
                    
                            
                        </>
                    ))
                  }
                  <tr> 
                  <td style={{borderRight:"none", borderTop:"2px solid grey"}}>Total</td>
                  <td style={{borderRight:"none", borderTop:"2px solid grey"}}></td>
                  <td style={{ borderTop:"2px solid grey"}}>{price}</td>
                  </tr>
                  
                </tbody>
                {/* <hr /> */}
               
            </table>
            <div className='card-detail'>
                <h4>Card Name</h4>
                <input type='text' placeholder='Enter Card Name '></input><br />
                <h4>Card Number</h4>
                <input type='number' placeholder='Enter Card Name '></input><br />
                <h4>Card Valid Date</h4>
                <input type='number' placeholder='Enter Date '></input><br />
                <br></br>
                <button onClick={()=>Navigate('/Paynow')} className='btn-pay'>PAY NoW</button>

            </div>
        </div>

    )
}
export default BuyNow