import React, { useState } from 'react'
import List from './List'

const Home = () => {
    const[arr,setArr]=useState([1,2,3,4])
    const [val,setVal]=useState(1)

  return (
    <div>
    <h3>value :{arr}</h3>
    <h2>val:{val}</h2>
        <button type='text' onClick={()=>setArr([arr[1],arr[2],arr[3],arr[3]+1])} >Add item</button>
        <button onClick={()=>setVal(val+1)}>Incriment</button>
        <List data={arr} />
    </div>
  )
}

export default Home