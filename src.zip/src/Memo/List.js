
import React, { memo } from 'react'


function List({data}) {
    console.log('hlo')
  return (
    <>

    {
       data.map((val , i)=>  <h3 key={i}> {val}</h3>
       )
    }
    </>

  )
}

export default memo(List)